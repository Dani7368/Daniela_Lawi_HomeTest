﻿// See https://aka.ms/new-console-template for more information


using Q3;
using System;
using System.Threading.Tasks;

class Program
{
    static void Main()
    {
       
    }
}