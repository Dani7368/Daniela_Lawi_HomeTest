﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q3
{
    public class PastaChef
    {
        public static async Task cookPastaDish(string pastaType, string sauceType)
        {
            var pottask = getPot();
            var pantask = getPan();
            var platetask = getPlate();

            var pot = await pottask;
            var pan = await pantask;

            var boilwatertask = boilWaterInPot(pot);
            var cookSaucetask = cookSauce(pan, sauceType);

            await boilwatertask;
            var cookPastatask = cookPasta(pot, pastaType);

            await Task.WhenAll(cookSaucetask, cookPastatask);
            var pasta = await cookPastatask;
            var sauce = await cookSaucetask;

            var mixedpasta = await mixPastaWithSauce(pasta, sauce);

            var plate = await platetask;
            var preparetask = preparePastaPlate(plate, mixedpasta);

            await preparetask;
            await serve(mixedpasta);
        }

        public class Pot { }
        public class Pan { }
        public class Plate { }
        public class Pasta { public string Type; public Pasta(string t) { Type = t; } }
        public class Sauce { public string Type; public Sauce(string t) { Type = t; } }

    }

}
