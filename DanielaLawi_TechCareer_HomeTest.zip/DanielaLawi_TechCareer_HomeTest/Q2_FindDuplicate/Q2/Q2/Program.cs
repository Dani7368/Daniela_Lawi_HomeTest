﻿// See https://aka.ms/new-console-template for more information


using Q2;
using System;
using System.Threading.Tasks;

class Program
{
    static void Main()
    {
        int[] a1 = { 1, 2, 3, 4, 4 };
        int[] a2 = { 1, 2, 3, 4, 2 };

        Console.WriteLine(Find_duplicate.Hasduplicate(a1));
        Console.WriteLine(Find_duplicate.Hasduplicate(a2));


    }
}