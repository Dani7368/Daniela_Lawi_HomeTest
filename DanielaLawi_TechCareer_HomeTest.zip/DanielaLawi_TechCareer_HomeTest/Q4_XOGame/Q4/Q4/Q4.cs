﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q4
{
    internal class XOgame
    {
        public static char XWon(char[,] borad)
        {
            int rows = borad.GetLength(0);
            int cols = borad.GetLength(1);

            for (int i = 0; i < rows; i++)
            {
                int j = 0;
                if (borad[i, j] == ' ')
                {
                    return '0';
                }

                while (j < cols && borad[i, j] == 'X')
                {
                    j++;
                }

                if (j == cols)
                {
                    return borad[i, j - 1];
                }

            }

            for (int j = 0; j < cols; j++)
            {
                int i = 0;
                if (borad[i, j] == ' ')
                {
                    return '0';
                }

                while (i < rows && borad[i, j] == 'X')
                {
                    i++;
                }

                if (i == rows)
                {
                    return borad[i - 1, j];
                }

            }

            if (rows == cols)
            {
                int i = 0, j = 0;
                if (borad[i, j] == ' ')
                {
                    return '0';
                }

                while ((i < rows) && (j < cols) && (borad[i, j] == 'X'))
                {
                    i++;
                    j++;
                }

                if (i == rows && j == cols)
                {
                    return borad[i - 1, j - 1];
                }

            }
            return '0';
        }

        public static char OWon(char[,] borad)
        {
            int rows = borad.GetLength(0);
            int cols = borad.GetLength(1);

            for (int i = 0; i < rows; i++)
            {
                int j = 0;
                if (borad[i, j] == ' ')
                {
                    return '0';
                }

                while (j < cols && borad[i, j] == 'O')
                {
                    j++;
                }

                if (j == cols)
                {
                    return borad[i, j - 1];
                }

            }

            for (int j = 0; j < cols; j++)
            {
                int i = 0;
                if (borad[i, j] == ' ')
                {
                    return '0';
                }

                while (i < rows && borad[i, j] == 'O')
                {
                    i++;
                }

                if (i == rows)
                {
                    return borad[i - 1, j];
                }

            }

            if (rows == cols)
            {
                int i = 0, j = 0;
                if (borad[i, j] == ' ')
                {
                    return '0';
                }

                while ((i < rows) && (j < cols) && (borad[i, j] == 'O'))
                {
                    i++;
                    j++;
                }

                if (i == rows && j == cols)
                {
                    return borad[i - 1, j - 1];
                }

            }
            return '0';
        }

    }

}
