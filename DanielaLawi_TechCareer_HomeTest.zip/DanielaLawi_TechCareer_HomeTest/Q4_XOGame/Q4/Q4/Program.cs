﻿// See https://aka.ms/new-console-template for more information

using Q4;
using System;
using System.Threading.Tasks;

class Program
{
    static void Main()
    {
        char[,] b1 = { { 'X', 'O', 'O' }, { 'X', 'O', 'X' }, { 'X', 'X', 'O' } }; //x won
        char[,] b2 = { { 'O', 'O', 'O' }, { 'X', 'O', 'X' }, { 'X', 'X', 'O' } }; //o won
        char[,] b3 = { { 'X', 'O', 'O' }, { 'X', 'O', 'X' }, { 'O', 'X', 'O' } }; //nobody


        char xwon = XOgame.XWon(b3);
        char owon = XOgame.OWon(b3);

        if (xwon == '0' && owon == '0')
        {
            Console.WriteLine("NOBODY WON");
        }
        else if (xwon == 'X')
        {
            Console.WriteLine(xwon + " WON");
        }
        else if (owon == 'O')
        {
            Console.WriteLine(owon + " WON");
        }
    }


    
}